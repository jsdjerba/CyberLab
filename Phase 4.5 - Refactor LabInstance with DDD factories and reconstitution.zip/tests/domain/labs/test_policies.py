import pytest
from domain.labs.policies.submission_policy import SubmissionPolicy
from domain.labs.policies.grading_policy import GradingPolicy
from domain.labs.exceptions import MaxAttemptsReached

def test_submission_policy_no_limit():
    policy = SubmissionPolicy(max_attempts=0)
    # Ne doit pas lever d'exception même à 100 tentatives
    policy.verify_can_submit(100) 

def test_submission_policy_under_limit():
    policy = SubmissionPolicy(max_attempts=3)
    policy.verify_can_submit(2) # OK

def test_submission_policy_at_limit():
    policy = SubmissionPolicy(max_attempts=3)
    with pytest.raises(MaxAttemptsReached):
        policy.verify_can_submit(3)

def test_grading_policy():
    policy = GradingPolicy()
    
    assert policy.calculate_xp(10, 1) == 10 # 100%
    assert policy.calculate_xp(10, 2) == 7 # 75% de 10 = 7.5 -> int(7)
    assert policy.calculate_xp(10, 3) == 5 # 50%
    assert policy.calculate_xp(10, 10) == 5 # Plafond bas à 50%
    assert policy.calculate_xp(0, 1) == 0