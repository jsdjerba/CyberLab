import pytest
from application.labs.services.step_validation_service import StepValidationService
from application.labs.exceptions import LabNotFoundError, LabInstanceNotFoundError
from domain.labs.entities.lab import Lab
from domain.labs.entities.step import Step
from domain.labs.entities.lab_instance import LabInstance
from domain.labs.value_objects.lab_id import LabId
from domain.labs.value_objects.step_id import StepId
from domain.labs.value_objects.step_type import StepType
from domain.labs.value_objects.student_id import StudentId
from domain.labs.exceptions import InvalidStepTransition
from domain.labs.events.step_completed import StepCompleted
from domain.labs.events.lab_finished import LabFinished

from infrastructure.fakes.fake_unit_of_work import FakeUnitOfWork
from infrastructure.fakes.fake_event_publisher import FakeEventPublisher
from infrastructure.fakes.fake_flag_validator import FakeFlagValidator

@pytest.fixture
def setup_data():
    uow = FakeUnitOfWork()
    publisher = FakeEventPublisher()
    # Le fake validera comme correct uniquement la chaîne "CTF{VALID}"
    validator = FakeFlagValidator(expected_flag="CTF{VALID}")
    
    # Lab avec deux étapes
    step1 = Step(StepId("s1"), StepType.FLAG, "Flag 1", 10)
    step2 = Step(StepId("s2"), StepType.FLAG, "Flag 2", 20)
    lab = Lab(LabId("L1"), "Test Lab", "Desc", "Easy", 30, [step1, step2])
    uow.labs.add(lab)
    
    # Instance déjà démarrée
    instance = LabInstance("inst_1", StudentId(1), LabId("L1"))
    instance.start_lab(lab)
    instance.pull_events() # Vider l'événement LabStarted
    uow.lab_instances.save(instance)
    
    service = StepValidationService(uow, validator, publisher)
    return service, uow, publisher, validator

def test_submit_correct_flag(setup_data):
    service, uow, publisher, _ = setup_data
    
    result = service.submit_flag(1, "L1", "s1", "CTF{VALID}")
    
    assert result.success is True
    assert result.score == 10
    assert result.current_step == "s2"
    assert result.completed is False
    assert uow.committed is True
    
    assert len(publisher.published_events) == 1
    assert isinstance(publisher.published_events[0], StepCompleted)
    assert publisher.published_events[0].step_id == "s1"

def test_submit_wrong_flag(setup_data):
    service, uow, publisher, _ = setup_data
    
    result = service.submit_flag(1, "L1", "s1", "CTF{WRONG}")
    
    assert result.success is False
    assert result.score == 0
    assert result.current_step == "s1"
    assert uow.committed is True
    
    # Vérification de l'incrément des tentatives en base factice
    instance = uow.lab_instances.get_by_student_and_lab(StudentId(1), LabId("L1"))
    assert instance.attempts.get("s1") == 1
    
    # Aucun événement métier n'est publié pour un fail
    assert len(publisher.published_events) == 0

def test_lab_not_found(setup_data):
    service, uow, publisher, _ = setup_data
    
    with pytest.raises(LabNotFoundError):
        service.submit_flag(1, "UNKNOWN", "s1", "CTF{VALID}")
        
    assert uow.committed is False

def test_instance_not_found(setup_data):
    service, uow, publisher, _ = setup_data
    
    with pytest.raises(LabInstanceNotFoundError):
        service.submit_flag(99, "L1", "s1", "CTF{VALID}")
        
    assert uow.committed is False

def test_invalid_step_transition(setup_data):
    service, uow, publisher, _ = setup_data
    
    # L'étudiant essaie de valider l'étape 2 alors qu'il est à l'étape 1
    with pytest.raises(InvalidStepTransition):
        service.submit_flag(1, "L1", "s2", "CTF{VALID}")
        
    assert uow.committed is False

def test_last_step_finishes_lab(setup_data):
    service, uow, publisher, _ = setup_data
    
    # Validation étape 1
    service.submit_flag(1, "L1", "s1", "CTF{VALID}")
    publisher.published_events.clear() # Reset events
    
    # Validation étape 2 (dernière étape)
    result = service.submit_flag(1, "L1", "s2", "CTF{VALID}")
    
    assert result.success is True
    assert result.score == 30
    assert result.current_step is None
    assert result.completed is True
    
    # Le moteur doit publier StepCompleted ET LabFinished
    assert len(publisher.published_events) == 2
    assert isinstance(publisher.published_events[0], StepCompleted)
    assert isinstance(publisher.published_events[1], LabFinished)

def test_publish_after_commit(setup_data):
    service, uow, publisher, _ = setup_data
    
    execution_order = []
    
    original_commit = uow.commit
    def tracking_commit():
        execution_order.append("COMMIT")
        original_commit()
    uow.commit = tracking_commit
    
    original_publish = publisher.publish
    def tracking_publish(event):
        execution_order.append("PUBLISH")
        original_publish(event)
    publisher.publish = tracking_publish
    
    service.submit_flag(1, "L1", "s1", "CTF{VALID}")
    
    assert execution_order == ["COMMIT", "PUBLISH"]