import uuid
from typing import List, Optional, Dict, Any

from domain.labs.value_objects.lab_id import LabId
from domain.labs.value_objects.student_id import StudentId
from domain.labs.value_objects.step_id import StepId
from domain.labs.value_objects.lab_status import LabStatus
from domain.events.event import DomainEvent

from domain.labs.events.lab_started import LabStarted
from domain.labs.events.step_completed import StepCompleted
from domain.labs.events.lab_finished import LabFinished
from domain.labs.exceptions import InvalidLabState, StepAlreadyCompleted, InvalidStepTransition

class LabInstance:
    """
    Aggregate Root : Instance de laboratoire.
    """

    def __init__(self, id: str, student_id: StudentId, lab_id: LabId):
        self.id = id
        self.student_id = student_id
        self.lab_id = lab_id
        self.status = LabStatus.NOT_STARTED
        self.score = 0
        self.current_step: Optional[StepId] = None
        self.completed_steps: List[StepId] = []
        self.attempts: Dict[str, int] = {}
        self._domain_events: List[DomainEvent] = []

    # --- MÉTHODES DDD (Factory Methods) ---

    @classmethod
    def create(cls, student_id: StudentId, lab_id: LabId) -> "LabInstance":
        """Point d'entrée métier pour une nouvelle instance."""
        return cls(id=str(uuid.uuid4()), student_id=student_id, lab_id=lab_id)

    @classmethod
    def reconstitute(cls, id: str, student_id: StudentId, lab_id: LabId, 
                     status: LabStatus, score: int, current_step: Optional[StepId], 
                     completed_steps: List[StepId], attempts: Dict[Any, int]) -> "LabInstance":
        """Point d'entrée technique pour la reconstruction depuis la DB."""
        instance = cls(id, student_id, lab_id)
        instance.status = status
        instance.score = score
        instance.current_step = current_step
        instance.completed_steps = completed_steps
        
        # Correction : on force les clés en string pour se protéger du Mapper
        instance.attempts = {
            (k.value if hasattr(k, 'value') else str(k)): v 
            for k, v in attempts.items()
        }
        
        instance._clear_events()
        return instance

    # --- MÉTHODES MÉTIER ---

    def pull_events(self) -> List[DomainEvent]:
        events = self._domain_events.copy()
        self._clear_events()
        return events

    def _clear_events(self) -> None:
        self._domain_events.clear()

    def start_lab(self, lab: Any) -> None:
        if self.status != LabStatus.NOT_STARTED:
            raise InvalidLabState("IN_PROGRESS")
        if not lab.steps:
            raise InvalidLabState("Le laboratoire ne contient aucune étape.")
            
        self.status = LabStatus.IN_PROGRESS
        self.current_step = lab.steps[0].id
        
        # Correction : LabStarted ne prend que l'instance_id en paramètre
        self._domain_events.append(LabStarted(self.id))

    def complete_step(self, step_id: StepId, lab: Any) -> None:
        if self.status != LabStatus.IN_PROGRESS:
            raise InvalidLabState("IN_PROGRESS")
        if step_id in self.completed_steps:
            raise StepAlreadyCompleted()
        if self.current_step != step_id:
            raise InvalidStepTransition()
        
        self.completed_steps.append(step_id)
        
        # Logique de score
        step = next((s for s in lab.steps if s.id == step_id), None)
        score_awarded = step.points if step else 0
        self.score += score_awarded
            
        # Formatage de l'ID attendu par l'événement (string)
        str_step_id = step_id.value if hasattr(step_id, 'value') else str(step_id)
        
        self._domain_events.append(StepCompleted(self.id, str_step_id, score_awarded))
            
        # Transition automatique
        remaining = [s for s in lab.steps if s.id not in self.completed_steps]
        if remaining:
            self.current_step = remaining[0].id
        else:
            self.current_step = None
            self.status = LabStatus.COMPLETED
            
            self._domain_events.append(LabFinished(self.id, self.score))

    def record_attempt(self, step_id: StepId, policy: Any) -> None:
        # Maintien du contrat Dict[str, int]
        step_key = step_id.value if hasattr(step_id, 'value') else str(step_id)
        self.attempts[step_key] = self.attempts.get(step_key, 0) + 1