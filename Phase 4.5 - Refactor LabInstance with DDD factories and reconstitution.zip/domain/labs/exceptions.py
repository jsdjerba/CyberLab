class LabDomainError(Exception):
    pass

class StepNotFound(LabDomainError):
    pass

class InvalidStepTransition(LabDomainError):
    pass

class StepAlreadyCompleted(LabDomainError):
    pass

class InvalidLabState(LabDomainError):
    pass

class MaxAttemptsReached(LabDomainError):
    pass