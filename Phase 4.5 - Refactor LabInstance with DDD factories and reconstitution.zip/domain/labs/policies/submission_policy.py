from domain.labs.exceptions import MaxAttemptsReached

class SubmissionPolicy:
    def __init__(self, max_attempts: int = 0):
        # 0 signifie "tentatives illimitées"
        self.max_attempts = max_attempts

    def verify_can_submit(self, attempts_count: int):
        if self.max_attempts > 0 and attempts_count >= self.max_attempts:
            raise MaxAttemptsReached(f"Maximum attempts ({self.max_attempts}) reached.")