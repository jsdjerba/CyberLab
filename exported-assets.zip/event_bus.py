
from typing import Protocol, Any


class EventBus(Protocol):
    """Port for the synchronous in-memory EventBus validated in earlier phases."""

    def publish(self, event: Any) -> None:
        ...
