
import pytest
from typing import Dict, List, Optional

from domain.progress.entities.progress import Progress
from domain.exceptions import UnauthorizedProgressAccessError, ProgressNotFoundError
from services.progress_service import ProgressService


class InMemoryProgressRepository:
    def __init__(self) -> None:
        self._store: Dict[str, Progress] = {}

    def get_by_student_and_lab(self, student_id: str, lab_id: str) -> Optional[Progress]:
        for p in self._store.values():
            if p.student_id == student_id and p.lab_id == lab_id:
                return p
        return None

    def get_by_id(self, progress_id: str) -> Optional[Progress]:
        return self._store.get(progress_id)

    def save(self, progress: Progress) -> None:
        self._store[progress.progress_id] = progress

    def list_by_student(self, student_id: str) -> List[Progress]:
        return [p for p in self._store.values() if p.student_id == student_id]


class FakeEventBus:
    def __init__(self) -> None:
        self.published = []

    def publish(self, event) -> None:
        self.published.append(event)


@pytest.fixture
def repository():
    return InMemoryProgressRepository()


@pytest.fixture
def event_bus():
    return FakeEventBus()


@pytest.fixture
def service(repository, event_bus):
    return ProgressService(repository=repository, event_bus=event_bus)


def test_start_progress_creates_new_record(service):
    dto = service.start_progress(student_id="s1", lab_id="lab1")
    assert dto.student_id == "s1"
    assert dto.status == "STARTED"


def test_start_progress_resumes_existing_record(service):
    first = service.start_progress(student_id="s1", lab_id="lab1")
    second = service.start_progress(student_id="s1", lab_id="lab1")
    assert first.progress_id == second.progress_id


def test_complete_progress_publishes_event(service, event_bus):
    dto = service.start_progress(student_id="s1", lab_id="lab1")
    completed = service.complete_progress(requesting_student_id="s1", progress_id=dto.progress_id)
    assert completed.status == "COMPLETED"
    assert len(event_bus.published) == 1
    assert event_bus.published[0].student_id == "s1"


def test_complete_progress_not_found_raises(service):
    with pytest.raises(ProgressNotFoundError):
        service.complete_progress(requesting_student_id="s1", progress_id="unknown-id")


def test_other_student_cannot_complete_progress(service):
    dto = service.start_progress(student_id="s1", lab_id="lab1")
    with pytest.raises(UnauthorizedProgressAccessError):
        service.complete_progress(requesting_student_id="s2", progress_id=dto.progress_id)
