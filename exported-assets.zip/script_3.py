
import textwrap

# --- Entity Tests ---
open(f"{base}/tests/test_progress_entity.py", "w").write(textwrap.dedent('''
    import pytest
    from datetime import datetime, timezone

    from domain.progress.entities.progress import Progress
    from domain.progress.value_objects.progress_status import ProgressStatus
    from domain.progress.events.lab_completed_event import LabCompletedEvent
    from domain.exceptions import InvalidProgressTransitionError, LabAlreadyCompletedError


    def test_create_progress_sets_started_status():
        p = Progress.start(student_id="s1", lab_id="lab1")
        assert p.status == ProgressStatus.STARTED
        assert p.student_id == "s1"
        assert p.lab_id == "lab1"
        assert p.completed_at is None


    def test_transition_started_to_completed():
        p = Progress.start(student_id="s1", lab_id="lab1")
        now = datetime.now(timezone.utc)
        p.complete(now=now)
        assert p.status == ProgressStatus.COMPLETED
        assert p.completed_at == now


    def test_double_completion_is_forbidden():
        p = Progress.start(student_id="s1", lab_id="lab1")
        p.complete()
        with pytest.raises(LabAlreadyCompletedError):
            p.complete()


    def test_cannot_revert_completed_to_started():
        p = Progress.start(student_id="s1", lab_id="lab1")
        p.complete()
        assert not p.status.can_transition_to(ProgressStatus.STARTED)


    def test_completion_generates_domain_event():
        p = Progress.start(student_id="s1", lab_id="lab1")
        p.complete()
        events = p.pull_events()
        assert len(events) == 1
        assert isinstance(events[0], LabCompletedEvent)
        assert events[0].student_id == "s1"
        assert events[0].lab_id == "lab1"


    def test_pull_events_clears_pending_events():
        p = Progress.start(student_id="s1", lab_id="lab1")
        p.complete()
        p.pull_events()
        assert p.pull_events() == []


    def test_student_id_and_lab_id_required():
        with pytest.raises(ValueError):
            Progress.start(student_id="", lab_id="lab1")
        with pytest.raises(ValueError):
            Progress.start(student_id="s1", lab_id="")
'''))

# --- Service Tests ---
open(f"{base}/tests/test_progress_service.py", "w").write(textwrap.dedent('''
    import pytest
    from typing import Dict, List, Optional

    from domain.progress.entities.progress import Progress
    from domain.exceptions import UnauthorizedProgressAccessError, ProgressNotFoundError
    from services.progress_service import ProgressService


    class InMemoryProgressRepository:
        def __init__(self) -> None:
            self._store: Dict[str, Progress] = {}

        def get_by_student_and_lab(self, student_id: str, lab_id: str) -> Optional[Progress]:
            for p in self._store.values():
                if p.student_id == student_id and p.lab_id == lab_id:
                    return p
            return None

        def get_by_id(self, progress_id: str) -> Optional[Progress]:
            return self._store.get(progress_id)

        def save(self, progress: Progress) -> None:
            self._store[progress.progress_id] = progress

        def list_by_student(self, student_id: str) -> List[Progress]:
            return [p for p in self._store.values() if p.student_id == student_id]


    class FakeEventBus:
        def __init__(self) -> None:
            self.published = []

        def publish(self, event) -> None:
            self.published.append(event)


    @pytest.fixture
    def repository():
        return InMemoryProgressRepository()


    @pytest.fixture
    def event_bus():
        return FakeEventBus()


    @pytest.fixture
    def service(repository, event_bus):
        return ProgressService(repository=repository, event_bus=event_bus)


    def test_start_progress_creates_new_record(service):
        dto = service.start_progress(student_id="s1", lab_id="lab1")
        assert dto.student_id == "s1"
        assert dto.status == "STARTED"


    def test_start_progress_resumes_existing_record(service):
        first = service.start_progress(student_id="s1", lab_id="lab1")
        second = service.start_progress(student_id="s1", lab_id="lab1")
        assert first.progress_id == second.progress_id


    def test_complete_progress_publishes_event(service, event_bus):
        dto = service.start_progress(student_id="s1", lab_id="lab1")
        completed = service.complete_progress(requesting_student_id="s1", progress_id=dto.progress_id)
        assert completed.status == "COMPLETED"
        assert len(event_bus.published) == 1
        assert event_bus.published[0].student_id == "s1"


    def test_complete_progress_not_found_raises(service):
        with pytest.raises(ProgressNotFoundError):
            service.complete_progress(requesting_student_id="s1", progress_id="unknown-id")


    def test_other_student_cannot_complete_progress(service):
        dto = service.start_progress(student_id="s1", lab_id="lab1")
        with pytest.raises(UnauthorizedProgressAccessError):
            service.complete_progress(requesting_student_id="s2", progress_id=dto.progress_id)
'''))
print("entity+service tests done")
