
import os, subprocess, textwrap

base = "cyberlab_progress"
dirs = [
    f"{base}/domain/progress/entities",
    f"{base}/domain/progress/value_objects",
    f"{base}/domain/progress/events",
    f"{base}/domain/dto",
    f"{base}/services/interfaces",
    f"{base}/services",
    f"{base}/tests",
]
for d in dirs:
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "__init__.py"), "w").close()

open(f"{base}/__init__.py", "w").close()
open(f"{base}/domain/__init__.py", "w").close()

# --- Value Object ---
open(f"{base}/domain/progress/value_objects/progress_status.py", "w").write(textwrap.dedent('''
    from enum import Enum

    class ProgressStatus(str, Enum):
        STARTED = "STARTED"
        COMPLETED = "COMPLETED"

        def can_transition_to(self, target: "ProgressStatus") -> bool:
            allowed = {
                ProgressStatus.STARTED: {ProgressStatus.COMPLETED},
                ProgressStatus.COMPLETED: set(),
            }
            return target in allowed[self]
'''))

# --- Domain Exceptions ---
open(f"{base}/domain/exceptions.py", "w").write(textwrap.dedent('''
    class DomainException(Exception):
        """Base class for all domain-level exceptions. Compatible with api.middleware.error_handler."""
        code: str = "DOMAIN_ERROR"

    class InvalidProgressTransitionError(DomainException):
        code = "INVALID_PROGRESS_TRANSITION"

    class LabAlreadyCompletedError(DomainException):
        code = "LAB_ALREADY_COMPLETED"

    class UnauthorizedProgressAccessError(DomainException):
        code = "UNAUTHORIZED_PROGRESS_ACCESS"

    class ProgressNotFoundError(DomainException):
        code = "PROGRESS_NOT_FOUND"
'''))

# --- Domain Event ---
open(f"{base}/domain/progress/events/lab_completed_event.py", "w").write(textwrap.dedent('''
    from dataclasses import dataclass, field
    from datetime import datetime, timezone
    import uuid

    @dataclass(frozen=True)
    class LabCompletedEvent:
        event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
        student_id: str = field(default="")
        lab_id: str = field(default="")
        completed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

        @classmethod
        def create(cls, student_id: str, lab_id: str, completed_at: datetime) -> "LabCompletedEvent":
            return cls(student_id=student_id, lab_id=lab_id, completed_at=completed_at)
'''))

print("scaffold created")
