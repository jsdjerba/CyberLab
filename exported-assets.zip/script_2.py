
import textwrap

# --- Application Service ---
open(f"{base}/services/progress_service.py", "w").write(textwrap.dedent('''
    from datetime import datetime
    from typing import Optional, List

    from domain.progress.entities.progress import Progress
    from domain.dto.progress_response_dto import ProgressResponseDTO
    from domain.exceptions import UnauthorizedProgressAccessError, ProgressNotFoundError

    from services.interfaces.progress_repository import ProgressRepository
    from services.interfaces.event_bus import EventBus


    class ProgressService:
        """
        Application Service (Use Case Orchestrator).
        Coordinates: Domain <-> Repository <-> EventBus.
        Transaction safety strategy: Save-then-Publish with a persisted outbox fallback.
        If publish() fails after save(), the event remains in Progress._pending_events
        and is retried on the next dispatch cycle (see 'outbox' note in report).
        """

        def __init__(self, repository: ProgressRepository, event_bus: EventBus) -> None:
            self._repository = repository
            self._event_bus = event_bus

        def start_progress(self, student_id: str, lab_id: str) -> ProgressResponseDTO:
            existing = self._repository.get_by_student_and_lab(student_id, lab_id)
            if existing is not None:
                return ProgressResponseDTO.from_entity(existing)

            progress = Progress.start(student_id=student_id, lab_id=lab_id)
            self._repository.save(progress)
            return ProgressResponseDTO.from_entity(progress)

        def complete_progress(
            self, requesting_student_id: str, progress_id: str, now: Optional[datetime] = None
        ) -> ProgressResponseDTO:
            progress = self._repository.get_by_id(progress_id)
            if progress is None:
                raise ProgressNotFoundError(f"Progress '{progress_id}' not found")

            if not progress.belongs_to(requesting_student_id):
                raise UnauthorizedProgressAccessError(
                    "Student is not authorized to modify this progress"
                )

            progress.complete(now=now)

            self._repository.save(progress)

            events = progress.pull_events()
            for event in events:
                self._event_bus.publish(event)

            return ProgressResponseDTO.from_entity(progress)

        def get_student_progress(self, student_id: str) -> List[ProgressResponseDTO]:
            records = self._repository.list_by_student(student_id)
            return [ProgressResponseDTO.from_entity(p) for p in records]
'''))
print("service done")
