
import subprocess
result = subprocess.run(
    ["python", "-m", "pytest", "-v", "--tb=short"],
    cwd=base, capture_output=True, text=True
)
print(result.stdout[-4000:])
print("STDERR:", result.stderr[-2000:])
