
import shutil, os

os.makedirs("output", exist_ok=True)
shutil.rmtree(f"{base}/.pytest_cache", ignore_errors=True)
for root, dirs, files in os.walk(base):
    if "__pycache__" in dirs:
        shutil.rmtree(os.path.join(root, "__pycache__"))

shutil.make_archive("output/cyberlab_phase5_1_progress_domain", "zip", base)
print("zip created")
