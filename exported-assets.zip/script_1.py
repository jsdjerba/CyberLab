
import textwrap

# --- Entity ---
open(f"{base}/domain/progress/entities/progress.py", "w").write(textwrap.dedent('''
    from dataclasses import dataclass, field
    from datetime import datetime, timezone
    from typing import Optional, List
    import uuid

    from domain.progress.value_objects.progress_status import ProgressStatus
    from domain.progress.events.lab_completed_event import LabCompletedEvent
    from domain.exceptions import InvalidProgressTransitionError, LabAlreadyCompletedError


    @dataclass
    class Progress:
        """
        Progress Entity - Aggregate Root.
        Encapsulates the lifecycle of a student's lab progression.
        Pure domain object: no Flask, no SQLAlchemy, no infrastructure knowledge.
        """
        student_id: str
        lab_id: str
        progress_id: str = field(default_factory=lambda: str(uuid.uuid4()))
        status: ProgressStatus = field(default=ProgressStatus.STARTED)
        started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
        completed_at: Optional[datetime] = field(default=None)

        _pending_events: List[LabCompletedEvent] = field(default_factory=list, repr=False, compare=False)

        def __post_init__(self) -> None:
            if not self.student_id:
                raise ValueError("student_id is required and immutable")
            if not self.lab_id:
                raise ValueError("lab_id is required and immutable")

        @classmethod
        def start(cls, student_id: str, lab_id: str) -> "Progress":
            return cls(student_id=student_id, lab_id=lab_id)

        def complete(self, now: Optional[datetime] = None) -> None:
            """
            Transitions progression from STARTED to COMPLETED.
            Raises domain exceptions if the invariant is violated.
            Collects a LabCompletedEvent for later publication by the Application layer.
            """
            if self.status == ProgressStatus.COMPLETED:
                raise LabAlreadyCompletedError(
                    f"Lab '{self.lab_id}' already completed for student '{self.student_id}'"
                )
            if not self.status.can_transition_to(ProgressStatus.COMPLETED):
                raise InvalidProgressTransitionError(
                    f"Cannot transition from {self.status} to COMPLETED"
                )

            completion_time = now or datetime.now(timezone.utc)
            self.status = ProgressStatus.COMPLETED
            self.completed_at = completion_time

            event = LabCompletedEvent.create(
                student_id=self.student_id,
                lab_id=self.lab_id,
                completed_at=completion_time,
            )
            self._pending_events.append(event)

        def is_completed(self) -> bool:
            return self.status == ProgressStatus.COMPLETED

        def belongs_to(self, student_id: str) -> bool:
            return self.student_id == student_id

        def pull_events(self) -> List[LabCompletedEvent]:
            """Returns and clears pending domain events. Entity never publishes events itself."""
            events = list(self._pending_events)
            self._pending_events.clear()
            return events
'''))

# --- DTO ---
open(f"{base}/domain/dto/progress_response_dto.py", "w").write(textwrap.dedent('''
    from dataclasses import dataclass
    from datetime import datetime
    from typing import Optional

    from domain.progress.entities.progress import Progress
    from domain.progress.value_objects.progress_status import ProgressStatus


    @dataclass(frozen=True)
    class ProgressResponseDTO:
        """Immutable output boundary object. Decouples API serialization from domain entity."""
        progress_id: str
        student_id: str
        lab_id: str
        status: str
        started_at: datetime
        completed_at: Optional[datetime]

        @classmethod
        def from_entity(cls, progress: Progress) -> "ProgressResponseDTO":
            return cls(
                progress_id=progress.progress_id,
                student_id=progress.student_id,
                lab_id=progress.lab_id,
                status=progress.status.value,
                started_at=progress.started_at,
                completed_at=progress.completed_at,
            )
'''))

# --- Interfaces (ports) ---
open(f"{base}/services/interfaces/progress_repository.py", "w").write(textwrap.dedent('''
    from typing import Protocol, Optional, List
    from domain.progress.entities.progress import Progress


    class ProgressRepository(Protocol):
        """Port. Implemented by infrastructure (SQLite/SQLAlchemy repository)."""

        def get_by_student_and_lab(self, student_id: str, lab_id: str) -> Optional[Progress]:
            ...

        def get_by_id(self, progress_id: str) -> Optional[Progress]:
            ...

        def save(self, progress: Progress) -> None:
            ...

        def list_by_student(self, student_id: str) -> List[Progress]:
            ...
'''))

open(f"{base}/services/interfaces/event_bus.py", "w").write(textwrap.dedent('''
    from typing import Protocol, Any


    class EventBus(Protocol):
        """Port for the synchronous in-memory EventBus validated in earlier phases."""

        def publish(self, event: Any) -> None:
            ...
'''))

print("entity, dto, interfaces done")
